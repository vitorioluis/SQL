declare @CAMPO nvarchar(30)  = 'CIA_NOME'
declare @TABELA nvarchar(30)  = 'CIA'
declare @COSULTA nvarchar(100)
DECLARE @ANO INT = 2010
declare @SOMA FLOAT = 10.22
declare @SOMA1 FLOAT  = 1.23


set @COSULTA = N'select '+@CAMPO+' ,'+CAST(ROUND((@SOMA + @SOMA1) / 2 ,2)AS NVARCHAR(10))+'AS SOMA FROM ' + @TABELA

EXEC (@COSULTA) 